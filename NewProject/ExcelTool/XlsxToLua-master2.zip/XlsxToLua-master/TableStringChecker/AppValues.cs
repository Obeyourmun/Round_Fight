﻿using System;
using System.Collections.Generic;
using System.Text;

public class AppValues
{
    /// <summary>
    /// lang文件转为键值对形式（key：lang文件中的key名， value：对应的在指定语言下的翻译）
    /// </summary>
    public static Dictionary<string, string> LangData = new Dictionary<string, string>();
}
